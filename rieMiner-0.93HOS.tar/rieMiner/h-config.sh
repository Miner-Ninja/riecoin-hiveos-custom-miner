#!/usr/bin/env bash

echo "Executing h-config.sh..."

CONFIG=""

if [[ $CUSTOM_URL == "stratum+tcp://"* ]]; then
	HOST=$(awk -F[/:] '{print $4}' <<< $CUSTOM_URL)
	PORT=$(awk -F[/:] '{print $5}' <<< $CUSTOM_URL)
	echo "Pooled Mining at $HOST, Port $PORT"
	CONFIG="${CONFIG}Mode = Pool"$'\n'
	CONFIG="${CONFIG}Host = $HOST"$'\n'
	CONFIG="${CONFIG}Port = $PORT"$'\n'
elif [[ $CUSTOM_URL == "http://"* ]]; then
	HOST=$(awk -F[/:] '{print $4}' <<< $CUSTOM_URL)
	PORT=$(awk -F[/:] '{print $5}' <<< $CUSTOM_URL)
	echo "Solo Mining at $HOST, Port $PORT"
	CONFIG="${CONFIG}Mode = Solo"$'\n'
	CONFIG="${CONFIG}Host = $HOST"$'\n'
	CONFIG="${CONFIG}Port = $PORT"$'\n'
fi

if [ ! -z "$CUSTOM_TEMPLATE" ]; then
	echo "Using Username or Username.worker $CUSTOM_TEMPLATE"
	CONFIG="${CONFIG}Username = $CUSTOM_TEMPLATE"$'\n'
fi

if [ ! -z "$CUSTOM_PASS" ]; then
	echo "Using Password"
	CONFIG="${CONFIG}Password = $CUSTOM_PASS"$'\n'
fi

if [ ! -z "$CUSTOM_USER_CONFIG" ]; then
	echo "Adding Custom User Config"
	CONFIG="${CONFIG}$CUSTOM_USER_CONFIG"$'\n'
fi

CONFIG="${CONFIG}APIPort = 2001"$'\n'

echo "rieMiner.conf:"
echo "================================================================"
echo "$CONFIG"
echo "================================================================"
echo "$CONFIG" > $CUSTOM_CONFIG_FILENAME
