#!/usr/bin/env bash

. h-manifest.conf

echo "Executing h-run.sh..."

USE_AVX2=$(lscpu | grep -c " avx2 ")

BIN=rieMinerHOS
if [ $USE_AVX2 == 1 ]; then
	echo "Using AVX2"
	BIN=rieMinerAVX2HOS
else
	echo "AVX2 not supported or not detected"
fi

echo "Starting $BIN..."
./$BIN $CUSTOM_CONFIG_FILENAME | tee --append $CUSTOM_LOG_BASENAME.log