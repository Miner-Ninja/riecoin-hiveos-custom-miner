#!/usr/bin/env bash

STATS=$(echo -n getstats | nc localhost 2001)
UPTIME=$(awk 'NR==2' <<< $STATS)
MININGPOWER=$(awk 'NR==6' <<< $STATS)
SHARES=$(awk 'NR==7' <<< $STATS)
SHARESREJECTED=$(awk 'NR==8' <<< $STATS)
SHARESACCEPTED=`expr $SHARES - $SHARESREJECTED`

MINERINFO=$(echo -n getminerinfo | nc localhost 2001)
VERSION=$(awk 'NR==2' <<< $MINERINFO)

stats='{"hs": ['"$MININGPOWER"'], "hs_units": "", "temp": [65], "fan": [50], "uptime": '"${UPTIME%.*}"', "ver": "'"$VERSION"'", "ar": ['"$SHARESACCEPTED, $SHARESREJECTED"'], "algo": "stella", "bus_numbers": []}'
khs=$MININGPOWER
